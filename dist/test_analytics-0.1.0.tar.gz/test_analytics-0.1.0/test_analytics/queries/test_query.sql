select
    *
from analytics.dim_user
limit 10