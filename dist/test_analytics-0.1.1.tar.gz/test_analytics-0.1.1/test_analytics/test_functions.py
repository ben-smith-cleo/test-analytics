def trial_inputs(first, second):
    return first + second
